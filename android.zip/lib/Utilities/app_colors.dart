import 'dart:ui';

class AppColors {
  static const Color smalltextColor = Color(0XFF999999);
  static const Color mainappColor = Color(0Xffc33a32);
  static const Color mainappsecondaryColor = Color(0XFF424242);
  static const Color textheadingColor = Color(0XFF001839);
  static const Color textheadingwhiteColor = Color(0XFFFFFFFF);
}
