package com.example.firebase_assessment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
